import 'package:flutter/material.dart';
import '../../data/models/property_response.dart';
import '../../data/models/search_property_dto.dart';
import '../../data/services/property_service.dart';

class SearchController {
  final cityController = TextEditingController();
  final priceFromController = TextEditingController();
  final priceToController = TextEditingController();
  final areaController = TextEditingController();

  int currentPage = 1;
  int total = 0;
  int limit = 5;
  bool isLoading = false;
  List<PropertyResponse> properties = [];

  final ValueNotifier<void> notifier = ValueNotifier(null);

  void dispose() {
    cityController.dispose();
    priceFromController.dispose();
    priceToController.dispose();
    areaController.dispose();
    notifier.dispose();
  }

  Future<void> search() async {
    isLoading = true;
    notifier.value = null;

    final dto = SearchPropertyDto(
      city: cityController.text.isNotEmpty ? cityController.text : null,
      priceFrom: int.tryParse(priceFromController.text),
      priceTo: int.tryParse(priceToController.text),
      page: currentPage,
      limit: limit,
    );

    try {
      final result = await PropertyService.searchProperties(dto);

      total = result.total;
      properties = result.data;

    } catch (e) {
      properties = [];
    } finally {
      isLoading = false;
      notifier.value = null;
      notifier.notifyListeners();
    }
  }

  void goToPage(int page) {
    currentPage = page;
    search();
  }
}
